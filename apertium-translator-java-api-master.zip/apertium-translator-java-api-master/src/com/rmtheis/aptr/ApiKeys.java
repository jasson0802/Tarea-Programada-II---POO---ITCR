package com.rmtheis.aptr;

public class ApiKeys {
	
  public static final String APERTIUM_API_KEY = "[Put your API key here]";
  
}
